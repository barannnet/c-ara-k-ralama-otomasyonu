﻿namespace Arac_Kiralama_Otomasyonu
{
    partial class AracEkle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AracEkle));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.plaka = new System.Windows.Forms.TextBox();
            this.ruhsat = new System.Windows.Forms.TextBox();
            this.marka = new System.Windows.Forms.TextBox();
            this.motorguc = new System.Windows.Forms.TextBox();
            this.model = new System.Windows.Forms.TextBox();
            this.motorhacim = new System.Windows.Forms.TextBox();
            this.renk = new System.Windows.Forms.TextBox();
            this.klimavar = new System.Windows.Forms.RadioButton();
            this.klimayok = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.yakit = new System.Windows.Forms.ComboBox();
            this.vites = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.sigortayok = new System.Windows.Forms.RadioButton();
            this.sigortavar = new System.Windows.Forms.RadioButton();
            this.tork = new System.Windows.Forms.TextBox();
            this.ucret = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.goster = new System.Windows.Forms.Label();
            this.deneme = new System.Windows.Forms.Label();
            this.muayene = new System.Windows.Forms.DateTimePicker();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.Name = "label4";
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.Name = "label5";
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.Name = "label6";
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.Name = "label7";
            // 
            // label8
            // 
            resources.ApplyResources(this.label8, "label8");
            this.label8.Name = "label8";
            // 
            // label9
            // 
            resources.ApplyResources(this.label9, "label9");
            this.label9.Name = "label9";
            // 
            // label10
            // 
            resources.ApplyResources(this.label10, "label10");
            this.label10.Name = "label10";
            // 
            // label11
            // 
            resources.ApplyResources(this.label11, "label11");
            this.label11.Name = "label11";
            // 
            // label12
            // 
            resources.ApplyResources(this.label12, "label12");
            this.label12.Name = "label12";
            // 
            // label13
            // 
            resources.ApplyResources(this.label13, "label13");
            this.label13.Name = "label13";
            // 
            // label14
            // 
            resources.ApplyResources(this.label14, "label14");
            this.label14.Name = "label14";
            // 
            // plaka
            // 
            resources.ApplyResources(this.plaka, "plaka");
            this.plaka.Name = "plaka";
            // 
            // ruhsat
            // 
            resources.ApplyResources(this.ruhsat, "ruhsat");
            this.ruhsat.Name = "ruhsat";
            // 
            // marka
            // 
            resources.ApplyResources(this.marka, "marka");
            this.marka.Name = "marka";
            // 
            // motorguc
            // 
            resources.ApplyResources(this.motorguc, "motorguc");
            this.motorguc.Name = "motorguc";
            this.motorguc.TextChanged += new System.EventHandler(this.motorguc_TextChanged);
            // 
            // model
            // 
            resources.ApplyResources(this.model, "model");
            this.model.Name = "model";
            // 
            // motorhacim
            // 
            resources.ApplyResources(this.motorhacim, "motorhacim");
            this.motorhacim.Name = "motorhacim";
            // 
            // renk
            // 
            resources.ApplyResources(this.renk, "renk");
            this.renk.Name = "renk";
            // 
            // klimavar
            // 
            resources.ApplyResources(this.klimavar, "klimavar");
            this.klimavar.Name = "klimavar";
            this.klimavar.TabStop = true;
            this.klimavar.UseVisualStyleBackColor = true;
            // 
            // klimayok
            // 
            resources.ApplyResources(this.klimayok, "klimayok");
            this.klimayok.Name = "klimayok";
            this.klimayok.TabStop = true;
            this.klimayok.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.klimayok);
            this.groupBox1.Controls.Add(this.klimavar);
            resources.ApplyResources(this.groupBox1, "groupBox1");
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.TabStop = false;
            // 
            // yakit
            // 
            resources.ApplyResources(this.yakit, "yakit");
            this.yakit.FormattingEnabled = true;
            this.yakit.Items.AddRange(new object[] {
            resources.GetString("yakit.Items"),
            resources.GetString("yakit.Items1"),
            resources.GetString("yakit.Items2")});
            this.yakit.Name = "yakit";
            // 
            // vites
            // 
            resources.ApplyResources(this.vites, "vites");
            this.vites.FormattingEnabled = true;
            this.vites.Items.AddRange(new object[] {
            resources.GetString("vites.Items"),
            resources.GetString("vites.Items1")});
            this.vites.Name = "vites";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.sigortayok);
            this.groupBox2.Controls.Add(this.sigortavar);
            resources.ApplyResources(this.groupBox2, "groupBox2");
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.TabStop = false;
            // 
            // sigortayok
            // 
            resources.ApplyResources(this.sigortayok, "sigortayok");
            this.sigortayok.Name = "sigortayok";
            this.sigortayok.TabStop = true;
            this.sigortayok.UseVisualStyleBackColor = true;
            // 
            // sigortavar
            // 
            resources.ApplyResources(this.sigortavar, "sigortavar");
            this.sigortavar.Name = "sigortavar";
            this.sigortavar.TabStop = true;
            this.sigortavar.UseVisualStyleBackColor = true;
            // 
            // tork
            // 
            resources.ApplyResources(this.tork, "tork");
            this.tork.Name = "tork";
            // 
            // ucret
            // 
            resources.ApplyResources(this.ucret, "ucret");
            this.ucret.Name = "ucret";
            // 
            // button1
            // 
            resources.ApplyResources(this.button1, "button1");
            this.button1.Name = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // goster
            // 
            resources.ApplyResources(this.goster, "goster");
            this.goster.Name = "goster";
            // 
            // deneme
            // 
            resources.ApplyResources(this.deneme, "deneme");
            this.deneme.ForeColor = System.Drawing.Color.Red;
            this.deneme.Name = "deneme";
            // 
            // muayene
            // 
            resources.ApplyResources(this.muayene, "muayene");
            this.muayene.Name = "muayene";
            this.muayene.ValueChanged += new System.EventHandler(this.muayene_ValueChanged);
            // 
            // AracEkle
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.muayene);
            this.Controls.Add(this.deneme);
            this.Controls.Add(this.goster);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.vites);
            this.Controls.Add(this.yakit);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.renk);
            this.Controls.Add(this.motorhacim);
            this.Controls.Add(this.model);
            this.Controls.Add(this.motorguc);
            this.Controls.Add(this.marka);
            this.Controls.Add(this.ucret);
            this.Controls.Add(this.tork);
            this.Controls.Add(this.ruhsat);
            this.Controls.Add(this.plaka);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "AracEkle";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.AracEkle_FormClosed);
            this.Load += new System.EventHandler(this.AracEkle_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox plaka;
        private System.Windows.Forms.TextBox ruhsat;
        private System.Windows.Forms.TextBox marka;
        private System.Windows.Forms.TextBox motorguc;
        private System.Windows.Forms.TextBox model;
        private System.Windows.Forms.TextBox motorhacim;
        private System.Windows.Forms.TextBox renk;
        private System.Windows.Forms.RadioButton klimavar;
        private System.Windows.Forms.RadioButton klimayok;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox yakit;
        private System.Windows.Forms.ComboBox vites;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton sigortayok;
        private System.Windows.Forms.RadioButton sigortavar;
        private System.Windows.Forms.TextBox tork;
        private System.Windows.Forms.TextBox ucret;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label goster;
        private System.Windows.Forms.Label deneme;
        private System.Windows.Forms.DateTimePicker muayene;
    }
}