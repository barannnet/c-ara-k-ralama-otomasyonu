# Arackiralama-Rentacar
Masaüstü Araç Kiralama Otomasyonu / Desktop Rent A Car Application

Araç kiralaması yapmak, araç kaydetmek, çalışan eklemek gibi işlevleri olan bir araç kiralama masaüstü uygulamasıdır. C# ve Mssql kullanılmıştır.

100'den fazla dosya olduğundan, lütfen projeyi rar olarak indirin.

It is a car rental desktop application with functions such as making car rentals, saving vehicles, adding employees. C # and Mssql were used.

Since there are more than 100 files, please download the project as rar.
